#!/bin/bash

creatAppIcon() {
  echo "\n正在制作App图标..."
  # 输出icon的目录
  icon_path="${projPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/ios/Images.xcassets/AppIcon.appiconset"

  if [ ! -e "$icon" ]; then
    echo "icon路径出错，请检查！！！"
    return -1
  fi

  if [ ! -e "$icon_path" ]; then
    echo "icon输出路径出错，请检查！！！"
    return -1
  fi

  # 删除旧的
  rm -r "${icon_path}"
  mkdir "${icon_path}"

  # 1024 icon 直接复制
  icon_1024_path="${icon_path}/Icon-1024.png"
  cp ${icon} ${icon_1024_path}

  # 确保icon是1024*1024
  sips -z 1024 1024 ${icon_1024_path} >/dev/null 2>&1

  if [ ! -e "$icon_1024_path" ]; then
    echo "1024icon复制失败"
    echo ${icon}
    echo ${icon_1024_path}
    return -1
  fi

  #用于复制小图，减少内存消耗
  prev_size_path=${icon_1024_path}

  # 需要生成的图标尺寸
  icons=(20 40 57 60 80 120 180 72 144 76 152 167 50 100 29 58 87 114)
  #icons=(20)
  for size in ${icons[@]}; do
    size_path="${icon_path}/Icon-${size}.png"
    cp ${prev_size_path} ${size_path}
    sips -Z $size ${size_path} >/dev/null 2>&1
    sips -s format png ${size_path} --out ${size_path} >/dev/null 2>&1

    [ $? -eq 0 ] && echo "info:\tresize ${size} successfully." || echo "info:\tresize ${size} failed."
  done

  #1024更改为jpg
  sips -s format jpeg ${icon_1024_path} --out ${icon_1024_path} >/dev/null 2>&1
  [ $? -eq 0 ] && echo "info:\tresize 1024 to jpg successfully." || echo "info:\tresize 1024 to jpg  failed."

  contents_json_path="${icon_path}/Contents.json"
  # 生成图标对应的配置文件
  echo '
{
  "images" : [
    {
      "size" : "40x40",
      "idiom" : "ipad",
      "filename" : "Icon-40.png",
      "scale" : "1x"
    },
    {
      "size" : "40x40",
      "idiom" : "ipad",
      "filename" : "Icon-80.png",
      "scale" : "2x"
    },
    {
      "size" : "60x60",
      "idiom" : "iphone",
      "filename" : "Icon-120.png",
      "scale" : "2x"
    },
    {
      "size" : "72x72",
      "idiom" : "ipad",
      "filename" : "Icon-72.png",
      "scale" : "1x"
    },
    {
      "size" : "72x72",
      "idiom" : "ipad",
      "filename" : "Icon-144.png",
      "scale" : "2x"
    },
    {
      "size" : "76x76",
      "idiom" : "ipad",
      "filename" : "Icon-76.png",
      "scale" : "1x"
    },
    {
      "size" : "76x76",
      "idiom" : "ipad",
      "filename" : "Icon-152.png",
      "scale" : "2x"
    },
    {
      "size" : "50x50",
      "idiom" : "ipad",
      "filename" : "Icon-50.png",
      "scale" : "1x"
    },
    {
      "size" : "50x50",
      "idiom" : "ipad",
      "filename" : "Icon-100.png",
      "scale" : "2x"
    },
    {
      "size" : "29x29",
      "idiom" : "iphone",
      "filename" : "Icon-29.png",
      "scale" : "1x"
    },
    {
      "size" : "29x29",
      "idiom" : "iphone",
      "filename" : "Icon-58.png",
      "scale" : "2x"
    },
    {
      "size" : "57x57",
      "idiom" : "iphone",
      "filename" : "Icon-57.png",
      "scale" : "1x"
    },
    {
      "size" : "57x57",
      "idiom" : "iphone",
      "filename" : "Icon-114.png",
      "scale" : "2x"
    },
    {
      "size" : "29x29",
      "idiom" : "iphone",
      "filename" : "Icon-87.png",
      "scale" : "3x"
    },
    {
      "size" : "40x40",
      "idiom" : "iphone",
      "filename" : "Icon-120.png",
      "scale" : "3x"
    },
    {
      "size" : "60x60",
      "idiom" : "iphone",
      "filename" : "Icon-180.png",
      "scale" : "3x"
    },
    {
      "size" : "40x40",
      "idiom" : "iphone",
      "filename" : "Icon-80.png",
      "scale" : "2x"
    },
    {
      "size" : "29x29",
      "idiom" : "ipad",
      "filename" : "Icon-29.png",
      "scale" : "1x"
    },
    {
      "size" : "29x29",
      "idiom" : "ipad",
      "filename" : "Icon-58.png",
      "scale" : "2x"
    },
    {
      "size" : "83.5x83.5",
      "idiom" : "ipad",
      "filename" : "Icon-167.png",
      "scale" : "2x"
    },
    {
      "size" : "20x20",
      "idiom" : "iphone",
      "filename" : "Icon-40.png",
      "scale" : "2x"
    },
    {
      "size" : "20x20",
      "idiom" : "iphone",
      "filename" : "Icon-60.png",
      "scale" : "3x"
    },
    {
      "size" : "20x20",
      "idiom" : "ipad",
      "filename" : "Icon-20.png",
      "scale" : "1x"
    },
    {
      "size" : "20x20",
      "idiom" : "ipad",
      "filename" : "Icon-40.png",
      "scale" : "2x"
    },
    {
      "size" : "1024x1024",
      "idiom" : "ios-marketing",
      "filename" : "Icon-1024.png",
      "scale" : "1x"
    }
  ],
  "info" : {
    "version" : 1,
    "author" : "xcode"
  }
}

' >${contents_json_path}
}

creatAppMeiXuan() {
  echo "\n正在制作美宣图片..."

  #美宣图的宽度
  meixSizeW=(2208 2688 2732)
  #美宣图的高度
  meixSizeH=(1242 1242 2048)

  out_path="${1}/美宣"
  mkdir -p $out_path

  count=1

  for file in $(ls $1); do
    if test -f "$1/${file}"; then
      sips -s format jpeg "$1/${file}" --out "$1/${file}"
    fi
  done

  for ((i = 0; i < ${#meixSizeW[@]}; i++)); do
    for file in $(ls $1); do
      if test -f "$1/${file}"; then
        #获得图片最终路径
        imgName="${meixSizeW[i]}*${meixSizeH[i]}_${count}.jpg"
        size_path="${out_path}/${imgName}"
        #复制图片
        cp "$1/${file}" ${size_path}
        #获取原图的宽高
        pixelWidth=$(sips -g pixelWidth "$1/${file}" | awk -F: '{print $2}')
        pixelHeight=$(sips -g pixelHeight "$1/${file}" | awk -F: '{print $2}')
        #根据原图的宽高比决定最后输出的横还是竖
        if test $pixelWidth -gt $pixelHeight; then
          sips -z ${meixSizeH[i]} ${meixSizeW[i]} ${size_path} >/dev/null 2>&1
        else
          sips -z ${meixSizeW[i]} ${meixSizeH[i]} ${size_path} >/dev/null 2>&1
        fi

        sips -s format jpeg ${size_path} --out ${size_path} >/dev/null 2>&1
        [ $? -eq 0 ] && echo "info:\tresize ${imgName} successfully." || echo "info:\tresize ${imgName} failed."
      fi
      ((count++))
    done
    ((count = 1))
  done
}

#取随机数
rand() {
  min=$1
  max=$(($2 - $min + 1))
  num=$(($RANDOM + 1000000000))
  echo $(($num % $max + $min))
}

setHealthDir() {
  echo "\n正在随机复制启动图片..."
  index=$(rand 1 6)
  sourceImage="${healthdir}/${index}.png"
  targetImage="${projPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/ios/LaunchScreenBackground.png"

  if [ ! -e "$projPath" ]; then
    echo "项目路径不正确，请检查！"
    return -1
  fi
  if [ ! -e "$targetImage" ]; then
    echo "找不到启动图片路径，请检查项目是否构建"
    return -1
  fi

  if [ ! -e "$sourceImage" ]; then
    echo "不存在健康忠告路径，请手动指定启动图片路径："
    read qidongPath
    cp $qidongPath $targetImage
  else
    cp $sourceImage $targetImage
  fi

  rm -rf /Users/mac/Library/Developer/Xcode/DerivedData/*
  xattr -rc "${projPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/"
}

openXcode() {
  echo "\n正在打开Xcode..."
  xcodeProjPath="${projPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/*.xcodeproj"

  if [ ! -e "${projPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/" ]; then
    echo "该项目路径下不存在Xcode项目文件，请检查项目路径是否正确及项目是否构建成功！"
    return -1
  fi

  open $xcodeProjPath
}

addOC() {

  echo "\n正在添加混淆代码..."

  if [ ! -e "${ocPath}/Model/" ]; then
    echo "混淆代码路径不正确，请检查！"
    return -1
  fi

  if [ ! -e "$projPath" ]; then
    echo "项目路径不正确，请检查！"
    return -1
  fi

  if [ -e "${ocPath}/InstanceFactory.h" ]; then
    rm "${ocPath}/InstanceFactory.h"
  fi
  if [ -e "${ocPath}/InstanceFactory.m" ]; then
    rm "${ocPath}/InstanceFactory.m"
  fi

  if [ -e "${porjOcPath}/CodeTest.h" ]; then
    return
  fi

  #复制混淆代码到项目目录下
  porjOcPath="${projPath}/build/jsb-default/frameworks/runtime-src/Classes/"
  if [ ! -e "$porjOcPath" ]; then
    echo "项目路径不正确，请检查！"
    return -1
  fi

  cp -r "$ocPath/" $porjOcPath

  if [ -e "${porjOcPath}/CodeTest.h" ]; then
    #在第10行添加一行代码
    sed -i "" $'10i\
    #import <UIKit/UIKit.h>'$'\n' "${porjOcPath}/CodeTest.h"

    #删除第14行代码
    sed -i "" '14d' "${porjOcPath}/CodeTest.h"

    #替换类名
    sed -i "" "s/CodeTest/${ocName}/g" "${porjOcPath}/CodeTest.h"

    #文件重命名
    mv "${porjOcPath}/CodeTest.h" "${porjOcPath}/${ocName}.h"
  fi

  if [ -e "${porjOcPath}/CodeTest.m" ]; then
    #替换类名
    sed -i "" "s/CodeTest/${ocName}/g" "${porjOcPath}/CodeTest.m"

    #文件重命名
    mv "${porjOcPath}/CodeTest.m" "${porjOcPath}/${ocName}.m"
  fi

  echo "\n混淆代码添加完毕，请手动到Xcode中添加引用..."
}

hotUpdate() {
  echo "正在热更新复制文件"

  if [ ! -e "$projPath" ]; then
    echo "项目路径不正确，请检查！"
    return -1
  fi
  if [ ! -e "$hotProjPath" ]; then
    echo "热更新项目路径不正确，请检查！"
    return -1
  fi

  if [ ! -e "${hotProjPath}/aes.d.ts" ]; then
    echo "热更新项目路径不正确"
    return -1
  fi
  if [ ! -e "${hotProjPath}/assets" ]; then
    echo "热更新项目路径不正确"
    return -1
  fi
  if [ ! -e "${hotProjPath}/build/jsb-default" ]; then
    echo "热更新项目路径不正确"
    return -1
  fi

  cp "${hotProjPath}/aes.d.ts" "${projPath}/aes.d.ts"
  cp "${hotProjPath}/jsb.d.ts" "${projPath}/jsb.d.ts"
  cp "${hotProjPath}/md5.d.ts" "${projPath}/md5.d.ts"
  cp "${hotProjPath}/pomelo.d.ts" "${projPath}/pomelo.d.ts"
  cp -r "${hotProjPath}/packages/hot-update-tools" "${projPath}/packages"

  echo "aes.d.ts、jsb.d.ts、md5.d.ts、pomelo.d.ts、/packages/hot-update-tools文件复制成功，请手动进入项目进行assets目录的操作\n请确认项目构建完毕后进行下一步"
  echo "确认构建完毕直接回车，否则输入任何按键后结束热更新流程"
  read continueC
  if [ -n "$continueC" ]; then
    return -1
  fi

  cp "${hotProjPath}/build/jsb-default/frameworks/cocos2d-x/extensions/assets-manager/AssetsManagerEx.cpp" "${projPath}/build/jsb-default/frameworks/cocos2d-x/extensions/assets-manager/AssetsManagerEx.cpp"
  cp "${hotProjPath}/build/jsb-default/frameworks/cocos2d-x/external/sources/unzip/unzip.cpp" "${projPath}/build/jsb-default/frameworks/cocos2d-x/external/sources/unzip/unzip.cpp"
  cp "${hotProjPath}/build/jsb-default/frameworks/cocos2d-x/external/sources/unzip/unzip.h" "${projPath}/build/jsb-default/frameworks/cocos2d-x/external/sources/unzip/unzip.h"
  cp -r "${hotProjPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/ios/utils" "${projPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/ios/"

  echo "AppController.h、AppController.mm、RootViewController.mm、RootViewController.h四个文件已经存在，是否直接覆盖？\n确认覆盖直接回车，否则输入任何按键后回车进行手动合并："
  read input
  if [ -z "$input" ]; then
    cp "${hotProjPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/ios/AppController.h" "${projPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/ios/AppController.h"
    cp "${hotProjPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/ios/AppController.mm" "${projPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/ios/AppController.mm"
    cp "${hotProjPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/ios/RootViewController.mm" "${projPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/ios/RootViewController.mm"
    cp "${hotProjPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/ios/RootViewController.h" "${projPath}/build/jsb-default/frameworks/runtime-src/proj.ios_mac/ios/RootViewController.h"
  fi

  echo "热更文件全部复制完毕，请手动到Xcode里面添加utils目录到引用，添加头文件搜索路径，添加StoreKit库，添加相册访问权限！"

}

#健康忠告的根目录
healthdir="/Users/mac/Documents/健康忠告"

case $1 in
"auto")
  #项目路径
  projPath=$2
  #icon图片路径
  icon=$3
  #OC混淆文件夹路径
  ocPath=$4
  #OC混淆文件需要更换的名称
  ocName=$5
  creatAppIcon
  setHealthDir
  addOC
  openXcode
  ;;

"icon")
  echo "制作图标功能"
  #项目路径
  projPath=$2
  #图片路径
  icon=$3
  creatAppIcon
  ;;
"meix")
  echo "制作美宣功能"
  #美宣图文件夹路径
  meixPath=$2
  creatAppMeiXuan $meixPath
  ;;
"qidong")
  echo "复制启动图功能"
  #项目路径
  projPath=$2
  setHealthDir
  ;;
"openXcode")
  #项目路径
  projPath=$2
  openXcode
  ;;
"addOC")
  #项目路径
  projPath=$2
  #OC混淆文件夹路径
  ocPath=$3
  #OC混淆文件需要更换的名称
  ocName=$4
  addOC
  ;;
"hotupdate")
  #项目路径
  projPath=$2
  #热更新项目路径
  hotProjPath=$3
  hotUpdate
  ;;
"help")
  echo "这是文档"
  echo "tibaoTool.sh是为了简化提包流程而制作出的一个脚本，主要功能有制作图标、制作美宣图片、复制启动图片、添加混淆代码、结束后自动打开Xcode等功能；
下面详细说一下：\n
复制启动图片功能：先把脚本打开，根据本地健康忠告路径自行更改“  healthdir  ”的路径，有两个参数，第一个为“  qidong  ”，第二个参数为项目的根路径\n
制作图标功能：有三个参数，第一个参数为“  icon  ”，第二个参数为项目的根路径，第三个为icon的路径\n
制作美宣图片功能：有两个参数，第一个参数为“  meix  ”，第二个参数为存放截图的目录，该目录下只能存放截图，制作好的结果会放到同级目录下的美宣目录下。\n
打开Xcode功能：有两个参数，第一个参数为“  openXcode  ”，第二个参数为项目的根路径，此功能会自动打开Xcode，避免一层一层的去选择目录\n
添加混淆代码功能：有四个参数，第一个参数为“  addOC  ”，第二个参数为项目的根路径，第三个参数为混淆代码文件夹的路径，第四个参数为为替换的类名
需要注意的是添加后需要到Xcode中执行一次“ Add Files to “xxx”... ”把混淆代码的引用添加进去
此操作避免了手动添加混淆后重命名时需要等待及有几率.h文件重命名失败\n
Auto功能：第一步制作图标、第二步复制启动图片，第三步添加混淆代码，第四步打开Xcode，全自动完成
五个参数，第一个参数为“  auto  ”，第二个参数为项目的根路径，第三个参数为icon的路径，第四个参数为混淆代码文件夹的路径，第五个参数为替换的类名
"
  ;;
*)
  echo "请输入正确的命令"
  ;;
esac
