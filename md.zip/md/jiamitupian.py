#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os,sys
import os.path
import filetype

#png的 加密处理
def encodeFile(infile, outfile):
    fr = open(infile, 'rb')
    key = 0x73
    inBuffer = fr.read()
    outBuffer = "ed![jA*w#"+chr(key)
    for b in inBuffer:
        outBuffer = outBuffer + chr(ord(b) ^ key)
    #print outBuffer
    open(outfile,'wb').write(outBuffer)
    fr.close();


def encodeDir(rootdir):
    for parent,dirnames,filenames in os.walk(rootdir):
        for filename in filenames:
            kind = filetype.guess(os.path.join(parent,filename))
            if kind is not None:
                if( kind.extension is "png")or ( kind.extension is "jpg") or (kind.extension is "webp") or (kind.extension is "bmp"):
                    #print('File extension: %s' % kind.extension)
                    print(os.path.join(parent,filename))
                    path1=os.path.join(parent,filename)
                    encodeFile(path1, path1)



print len(sys.argv)
if len(sys.argv) !=2:
    print '参数错误'
else:
    encodeDir(sys.argv[1])




