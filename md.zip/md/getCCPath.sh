str1=$1
str2=$2
projPath=$3

# 检测所需环境
if command -v ruby >/dev/null 2>&1; then
    echo ""
else
    export HOMEBREW_NO_AUTO_UPDATE=true
    brew install rpl
fi

IFS=$'\n'
set -f
for n in $(ls "/Applications/"); do
    if [[ "/Applications/$n" =~ "CocosCreator" ]]; then
        cocosPath="/Applications/$n/Contents/Resources/static/default-assets"
        if [ -d "$cocosPath" ]; then
            ret=$(find "$cocosPath" | xargs grep -ri "${str1}" -l | awk -F: '{print $1}')
            if [ -n "$ret" ]; then
                echo $1
                exit
            fi
        fi
    fi
done

rpl -R $str1 $str2 $projPath
