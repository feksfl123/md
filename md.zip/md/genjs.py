#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import os.path
import random
import string
import base64


def genRand(num):
    return ''.join(random.sample(string.ascii_letters, num))


def modifyk_js(jsFlile):
    data_list = []
    file_lines = open(jsFlile, 'r').readlines()
    for i, file_data in enumerate(file_lines):
        # for file_data in file_lines:
        for src in file_data:
            data_list.append(src)
            if src == ";" and random.randint(1, 2) == 2 and ("for" not in file_data) and ('"') not in file_data and('\'') not in file_data:
                if i > 0 and 'else' not in file_lines[i-1] and 'if' not in file_lines[i-1]:
                    for item in range(random.randint(1, 8)):
                        code = "var %s = \"%s\";" % (
                            genRand(random.randint(4, 8)), genRand(random.randint(5, 18)))
                        data_list.append('\n')
                        data_list.append(code)
    data = ''.join(data_list)
    open(jsFlile, 'w').write(data)


if __name__ == '__main__':
    rootDir = sys.argv[1]

    for parent, dirnames, filenames in os.walk(rootDir):
        for file in filenames:
            jspath = os.path.join(parent, file)
            if os.path.splitext(jspath)[1] == '.js':
                modifyk_js(jspath)
