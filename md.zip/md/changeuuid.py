# coding=utf-8

import os
import sys
import json
import random
import string
import time
import datetime
from concurrent.futures import ProcessPoolExecutor
import fcntl

import_json_set = set()
uuid_new_list = []
fileList = []
app = ""


def listFiles(dirPath):

    for root, dirs, files in os.walk(dirPath):
        for fileObj in files:
            path = os.path.join(root, fileObj)
            if fileObj[0:] != '.':
                fileList.append(path)


def read_impore_json(rootPath):
    # 构建后 res/import 的路径
    importPath = "%s/../build/jsb-default/res/import" % rootPath

    if not os.path.exists(importPath):
        print("没有找到构建目录，正在执行构建")
        os.system('/Applications/%s.app/Contents/MacOS/CocosCreator --path %s/.. --build "platform=ios;template=default;md5Cache=false"' %
                  (app, rootPath))

    list_dirs = os.walk(importPath)
    for root, dirs, files in list_dirs:
        for f in files:
            if "json" == f[-4:]:
                import_json_set.add(f[0:-5])


def replaceName(str1):
    if isDefaultUUID(str1):
        return
    str2 = random_uuid()
    print('Run task  (%s)... 替换uuid {%s} 为 {%s} ' % (os.getpid(), str1, str2))
    for filePath in fileList:
        try:
            with open(filePath, 'r+') as f:
                fcntl.flock(f, fcntl.LOCK_EX)
                c = f.read()
                c = c.replace(str1, str2)
                f.seek(0)
                f.truncate()
                f.write(c)
        except:
            pass
    uuid_new_list.append(str2)


def random_uuid():
    uuid = "%s-%s-%s-%s-%s" % (genRand(8), genRand(4),
                               genRand(4), genRand(4), genRand(12))
    if uuid in uuid_new_list:
        random_uuid()
    return uuid


def genRand(num):
    return ''.join(random.sample(string.ascii_lowercase + string.digits, num))


def remove_dir(dirs):
    for r_dir in dirs:
        if os.path.exists(r_dir):
            os.system("rm -r %s" % r_dir)


def isDefaultUUID(uuid):
    defaultPath = "/Applications/%s.app/Contents/Resources/static/default-assets" % app
    for root, dirs, files in os.walk(defaultPath):
        for fileObj in files:
            path = os.path.join(root, fileObj)
            try:
                with open(path, 'r') as f:
                    fcntl.flock(f, fcntl.LOCK_EX)
                    c = f.read()
                    if uuid in c:
                        return True
            except:
                pass
    return False


if __name__ == '__main__':
    starttime = datetime.datetime.now()

    # root目录为assets目录
    rootPath = sys.argv[1]
    # cocos creator 路径
    app = sys.argv[2]

    # 临时文件路径
    libraryPath = "%s/../library" % rootPath
    localPath = "%s/../local" % rootPath
    tempPath = "%s/../temp" % rootPath

    # 读取构建后import下所有json文件的文件名称并存在Set中
    read_impore_json(rootPath)

    # 读取所有文件
    listFiles(rootPath)

    # 遍历替换
    p = ProcessPoolExecutor()
    p.map(replaceName, import_json_set)
    p.shutdown()

    # 删除临时目录
    remove_dir([libraryPath, localPath, tempPath])

    endtime = datetime.datetime.now()
    print("脚本执行时间为：%d" % (endtime - starttime).seconds)
